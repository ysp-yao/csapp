/**
 * UW CSE 351 Spring 2016 Lab 5
 *
 * Extra credit: implementing mm_realloc
 *
 * This requires mm_malloc and mm_free to be working correctly, so
 * don't start on this until you finish mm.c.
 */
#include "mm.c"

// Extra credit.
void* mm_realloc(void* ptr, size_t size) {
    // Write your code here ...

    return NULL;
}
